SELECT 	ssn
  FROM 	employee;