SELECT *
FROM employee
WHERE DNO = 5;