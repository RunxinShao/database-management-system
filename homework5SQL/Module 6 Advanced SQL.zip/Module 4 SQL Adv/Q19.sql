select 	* 
 	from 	student;























