drop table student;
create table student(
 sno varchar(10) not null unique,
 sname varchar(20),
 sage int(2),
 ssex varchar(5)
);

