ALTER TABLE sc
DROP FOREIGN KEY sc_sno_fk;




